CREATE TABLE combined AS 
WITH cte AS (SELECT *FROM bike_share_yr_0
UNION ALL
SELECT *
FROM bike_share_yr_1)
SELECT
dteday,
season,
a.yr,
weekday,
hr,
rider_type,
riders,
price,
COGS,
riders*COGS AS revenue,
riders*price- COGS*riders AS profit
FROM cte a
JOIN cost_table b
ON 
a.yr=b.yr